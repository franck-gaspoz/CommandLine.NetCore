﻿using CommandLine.NetCore.Services.CmdLine.Commands;

using IRCEM.CiCd.SqlDeployer.Services.Config;

namespace IRCEM.CiCd.SqlDeployer.Services;

class CommandServices
{
    public Dependencies Dependencies { get; }

    public ConfigManager ConfigManager { get; }

    public Error Error { get; }

    public CommandServices(
        Dependencies dependencies,
        ConfigManager configManager,
        Error error
        )
    {
        Dependencies = dependencies;
        ConfigManager = configManager;
        Error = error;
    }
}
