﻿using System.Transactions;

namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

/// <summary>
/// .net ambient transaction
/// </summary>
public static class AmbiantTransaction
{
    /// <summary>
    /// fabrique et retourne une nouvelle transaction ambiant
    /// <para>usage: using (AmbiantTransaction.New()) { ... }</para>
    /// </summary>
    /// <returns></returns>
    public static TransactionScope New()
        => new(
            TransactionScopeOption.Required,
            new TransactionOptions
            {
                IsolationLevel = IsolationLevel.ReadUncommitted
            },
            TransactionScopeAsyncFlowOption.Enabled
            );
}
