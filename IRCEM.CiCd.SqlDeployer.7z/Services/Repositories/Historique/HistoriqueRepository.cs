﻿using IRCEM.CiCd.SqlDeployer.Services.Config;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git.Models;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique.Extensions;

using Microsoft.EntityFrameworkCore;

namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

sealed class HistoriqueRepository
{
    readonly HistoriqueDbContext _dbContext;
    readonly ConfigManager _configManager;
    readonly TypesDbs _typeDb;

    public HistoriqueRepository(
        ConfigManager configManager,
        TypesDbs typeDb,
        string connexionString)
            => (_dbContext, _configManager, _typeDb) =
                (new(typeDb, connexionString), configManager, typeDb);

    public async Task<int> DropTable(
        bool simule,
        string? dumpSql)
    {
        var script = _configManager
            .GetDbScriptsSettings(_typeDb)
            .DropTableHistorique;

        if (dumpSql is not null)
        {
            File.AppendAllText(dumpSql, "-- initialisation de l'historique");
            File.AppendAllText(dumpSql, Environment.NewLine);
            File.AppendAllText(dumpSql, Environment.NewLine);
            File.AppendAllText(dumpSql, script);
            File.AppendAllText(dumpSql, Environment.NewLine);
            File.AppendAllText(dumpSql, Environment.NewLine);
        }

        return simule? -1 : await _dbContext
            .Database
                .ExecuteSqlRawAsync(script);
    }

    public async Task<int> CreateTable(
        bool simule,
        string? dumpSql)
    {
        var script = _configManager
            .GetDbScriptsSettings(_typeDb)
            .CreateTableHistorique;

        if (dumpSql is not null)
        {
            File.AppendAllText(dumpSql, script);
            File.AppendAllText(dumpSql,Environment.NewLine);
            File.AppendAllText(dumpSql,Environment.NewLine);
        }

        return simule ? -1 : await _dbContext
            .Database
                .ExecuteSqlRawAsync(script);
    }

    /// <summary>
    /// donne le dernier n° de build (rollback ou pas)
    /// </summary>
    /// <returns>valeur du build ou aucun si non trouvé</returns>
    public async Task<string?> GetCurrentBuild()
        => (await _dbContext
            .HistoriquesSQL
            .OrderByDescending(x => x.Id)
            .FirstOrDefaultAsync())
                ?.Build;

    public async Task<int?> GetLastScript()
    {
        var build = await GetCurrentBuild();
        return build is null
            ? null
            : ((await _dbContext
                .HistoriquesSQL
                .Where(x => !x.IsRollback
                    && x.Build == build)
                .OrderByDescending(x => x.Script)
                .FirstOrDefaultAsync())
                ?.Script);
    }

    public async Task<int?> GetScriptAtBuild(string build)
        => (await _dbContext
            .HistoriquesSQL
            .Where(x => !x.IsRollback
                && x.Build == build)
            .OrderByDescending(x => x.Script)
            .FirstOrDefaultAsync())
            ?.Script;

    /// <summary>
    /// indique les updates a effectuer en examinant le delta entre la table d'historique et les scripts dans le repo
    /// </summary>
    /// <param name="gitRepo">git repository</param>
    /// <param name="dbId">db id de la base concernée</param>
    /// <param name="noScript">n° script max retourné si différent de -1</param>
    /// <returns>list of update scripts</returns>
    public async Task<List<SQLScript>> GetUpdates
        (GitRepository gitRepo,
        string dbId,
        int noScript = -1)
    {
        var currentScript = await GetLastScript();
        currentScript ??= -1;

        var updates = gitRepo
            .SqlScripts
                .GetUpdates(
                    dbId,
                    currentScript!.Value);

        if (noScript != -1)
            updates =
                updates.Where(x => x.Number <= noScript);

        return updates.ToList();
    }

    /// <summary>
    /// liste complète de l'historique triée par ordre d'ajout
    /// </summary>
    /// <returns>liste des items de l'historique</returns>
    public async Task<List<HistoriqueSQL>> GetList()
        => await _dbContext
            .HistoriquesSQL
            .OrderBy(x => x.Id)
            .ToListAsync();

    /// <summary>
    /// scripts actuellement livrés
    /// </summary>
    /// <returns>liste des items de l'historique actuellement livrés</returns>
    public async Task<List<HistoriqueSQL>> GetDelivered()
    {
        var list = await GetList();
        var flatList = new List<HistoriqueSQL>();
        foreach (var item in list)
        {
            if (!item.IsRollback)
                flatList.Add(item);
            else
            {
                var rmItem = flatList
                    .Where(x => x.Script == item.Script)
                    .FirstOrDefault();
                if (rmItem is not null)
                    flatList.Remove(rmItem);
            }
        }
        return flatList;
    }

    /// <summary>
    /// indique les rollbacks a effectuer en examinant le delta entre la table d'historique et les scripts dans le repo
    /// </summary>
    /// <param name="gitRepo">git repository</param>
    /// <param name="dbId">db id de la base concernée</param>
    /// <param name="build">le build vers lequel rollbacké</param>
    /// <param name="error">error</param>
    /// <returns>list of rollbacks scripts</returns>
    public async Task<List<SQLScript>> GetRollbacks
        (GitRepository gitRepo,
        string dbId,
        string build)
    {
        var targetScript = await GetScriptAtBuild(build);
        targetScript ??= -1;

        var currentScript = await GetLastScript();
        var updateScripts = new List<SQLScript>();
        if (currentScript.HasValue)
            updateScripts = gitRepo
                .SqlScripts
                    .GetUpdates(
                        dbId,
                        currentScript!.Value)
                    .ToList();

        var rollbacks = gitRepo
            .SqlScripts
                .GetRollbacks(
                    dbId,
                    targetScript!.Value)
                .Where(x => !updateScripts.Any(
                    y => y.Number == x.Number));

        return rollbacks.ToList();
    }

    public async Task AddUpdates(
        string build, 
        IEnumerable<SQLScript> scripts,
        bool simule,
        string? dumpSql)
    {
        var items = scripts.Select(x => ToEntity(build, x));

        if (dumpSql is not null)
        {
            File.AppendAllText(dumpSql, Environment.NewLine);
            File.AppendAllText(dumpSql, Environment.NewLine);
            File.AppendAllText(dumpSql, "-- mise à jour de l'historique");
            File.AppendAllText(dumpSql, Environment.NewLine);
            File.AppendAllText(dumpSql, Environment.NewLine);

            foreach (var item in items)
            {
                var sql = _configManager
                    .GetDbScriptsSettings(_typeDb)
                    .InsertTableHistorique
                    .Replace("{build}", item.Build)
                    .Replace("{script}", item.Script.ToString())
                    .Replace("{rollback}", (item.IsRollback ? 1 : 0).ToString())
                    .Replace("{description}", item.Description);

                File.AppendAllText(dumpSql,sql);
                File.AppendAllText(dumpSql, Environment.NewLine);
                File.AppendAllText(dumpSql, Environment.NewLine);
            }
        }

        if (!simule)
        {
            await _dbContext.AddRangeAsync(items);
            _ = await _dbContext.SaveChangesAsync();
        }
    }

    HistoriqueSQL ToEntity(string build, SQLScript sqlScript)
        => new(
               _typeDb == TypesDbs.Postgresql
                    ? DateTime.Now.ConvertDateTimeLocalToUTC()
                    : DateTime.Now,
               build,
               sqlScript.Number,
               sqlScript.IsRollback,
               sqlScript.Description
            );

    public async Task<(bool exists, string? error)> CheckExists()
    {
        try
        {
            _ = await
                _dbContext.HistoriquesSQL
                    .FirstOrDefaultAsync();
            return (true, null);
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }

    public async Task<int> RunScript(SQLScript script)
    {
        var sql = script.SQL;
        sql = sql.Replace("{{", "{{{{")
            .Replace("}}","}}}}");
        return await _dbContext
            .Database
                .ExecuteSqlRawAsync(sql);
    }
}
