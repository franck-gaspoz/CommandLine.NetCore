﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

[Table("HistoriqueSQL")]
class HistoriqueSQL
{
    [Key]
    [Required]
    public long? Id { get; set; }

    public DateTime Date { get; set; }

    public string Build { get; set; }

    public int Script { get; set; }

    public bool IsRollback { get; set; }

    public string Description { get; set; }

    public HistoriqueSQL(
        DateTime date,
        string build,
        int script,
        bool isRollback,
        string description,
        long? id = null)
    {
        Id = id;
        Date = date;
        Build = build;
        Script = script;
        IsRollback = isRollback;
        Description = description;
    }
}
