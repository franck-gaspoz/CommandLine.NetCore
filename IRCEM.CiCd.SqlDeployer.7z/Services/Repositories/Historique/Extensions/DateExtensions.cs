﻿namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique.Extensions;

/// <summary>
/// méthodes d'extensions sur les classes dates
/// </summary>
public static class DateExtensions
{
    /// <summary>
    /// convertit un date locale en utc
    /// </summary>
    /// <param name="date">date locale</param>
    /// <returns>date utc</returns>
    public static DateTime? ConvertDateTimeLocalToUTC(this DateTime? date) => date == null
            ? null
            : date.Value.Kind == DateTimeKind.Utc
            ? date
            : date.Value.Kind == DateTimeKind.Unspecified
            ? new DateTime(date!.Value.Year, date!.Value.Month, date!.Value.Day,
                date!.Value.Hour, date!.Value.Minute,
                date!.Value.Second, DateTimeKind.Utc)
            : TimeZoneInfo
            .ConvertTimeToUtc(
                date.Value,
                TimeZoneInfo.Local);

    /// <summary>
    /// convertit un date locale en utc
    /// </summary>
    /// <param name="date">date locale</param>
    /// <returns>date utc</returns>
    public static DateTime ConvertDateTimeLocalToUTC(this DateTime date) => date.Kind == DateTimeKind.Utc
            ? date
            : date.Kind == DateTimeKind.Unspecified
            ? new DateTime(date.Year, date.Month, date.Day,
                date!.Hour, date!.Minute,
                date!.Second, DateTimeKind.Utc)
            : TimeZoneInfo
            .ConvertTimeToUtc(
                date,
                TimeZoneInfo.Local);

    /// <summary>
    /// convertit un date only locale en utc
    /// </summary>
    /// <param name="date">date locale</param>
    /// <returns>date utc</returns>
    public static DateTime ConvertDateOnlyLocalToUTC(this DateOnly date)
        => date.ToDateTime().ConvertDateTimeLocalToUTC();

    /// <summary>
    /// convertit une date utc en locale
    /// </summary>
    /// <param name="date">date utc</param>
    /// <returns>date locale</returns>
    public static DateTime? ConvertDateTimeUTCToLocal(this DateTime? date) => date == null
            ? null
            : date.Value.Kind == DateTimeKind.Local
            ? date
            : date.Value.Kind == DateTimeKind.Unspecified
            ? new DateTime(date!.Value.Year, date!.Value.Month,
                date!.Value.Day, date!.Value.Hour, date!.Value.Minute,
                date!.Value.Second, DateTimeKind.Local)
            : TimeZoneInfo
            .ConvertTimeFromUtc(
                date.Value,
                TimeZoneInfo.Local);

    /// <summary>
    /// convertit une date utc en locale
    /// </summary>
    /// <param name="date">date utc</param>
    /// <returns>date locale</returns>
    public static DateTime ConvertDateTimeUTCToLocal(this DateTime date) => date.Kind == DateTimeKind.Local
            ? date
            : date.Kind == DateTimeKind.Unspecified
            ? new DateTime(date.Year, date.Month,
                date.Day, date.Hour, date.Minute,
                date.Second, DateTimeKind.Local)
            : TimeZoneInfo
            .ConvertTimeFromUtc(
                date,
                TimeZoneInfo.Local);

    /// <summary>
    /// convertit une date utc en date only locale
    /// </summary>
    /// <param name="date">date</param>
    /// <returns>date only locale</returns>
    public static DateOnly? ConvertDateTimeUTCToLocalDateOnly(this DateTime? date)
        => date == null ? null
            : DateOnly.FromDateTime(date.ConvertDateTimeUTCToLocal()!.Value);

    /// <summary>
    /// convertit une date utc en date only locale
    /// </summary>
    /// <param name="date">date</param>
    /// <returns>date only locale</returns>
    public static DateOnly ConvertDateTimeUTCToLocalDateOnly(this DateTime date)
        => DateOnly.FromDateTime(((DateTime?)date).ConvertDateTimeUTCToLocal()!.Value);

    /// <summary>
    /// convertit une date local en date only utc
    /// </summary>
    /// <param name="date">date</param>
    /// <returns>date only utc</returns>
    public static DateOnly? ConvertDateTimeLocalToUTCDateOnly(this DateTime? date)
        => date == null ? null
            : DateOnly.FromDateTime(date.ConvertDateTimeLocalToUTC()!.Value);

    /// <summary>
    /// convertit un date time vers un date only
    /// </summary>
    /// <param name="dateTime">date time à convertir</param>
    /// <returns>date only ou null di dateTime est null</returns>
    public static DateOnly? ToDateOnly(this DateTime? dateTime)
        => dateTime == null
            ? null
            : DateOnly.FromDateTime(dateTime!.Value);

    /// <summary>
    /// convertit un date time vers un date only
    /// </summary>
    /// <param name="dateTime">date time à convertir</param>
    /// <returns>date only</returns>
    public static DateOnly ToDateOnly(this DateTime dateTime)
        => DateOnly.FromDateTime(dateTime);

    /// <summary>
    /// transforme une date time en date only à minuit
    /// </summary>
    /// <param name="dateOnly">date sans heur</param>
    /// <returns>date avec heur à minuit</returns>
    public static DateTime ToDateTime(this DateOnly dateOnly)
        => dateOnly.ToDateTime(TimeOnly.MinValue);

}
