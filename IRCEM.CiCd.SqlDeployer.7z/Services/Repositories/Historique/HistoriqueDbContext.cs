﻿using IRCEM.CiCd.SqlDeployer.Services.Config;

using Microsoft.EntityFrameworkCore;

namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

sealed class HistoriqueDbContext : DbContext
{
    readonly TypesDbs _typeDb;
    readonly string _connexionString;

    public HistoriqueDbContext(
        TypesDbs typeDb,
        string connexionString)
        => (_typeDb, _connexionString)
            = (typeDb, connexionString);

    public DbSet<HistoriqueSQL> HistoriquesSQL => Set<HistoriqueSQL>();

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        switch (_typeDb)
        {
            case TypesDbs.Postgresql:
                _ = optionsBuilder.UseNpgsql(_connexionString);
                break;
            case TypesDbs.SqlServer:
                _ = optionsBuilder.UseSqlServer(_connexionString);
                break;
        }
    }
}
