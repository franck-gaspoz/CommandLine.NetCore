﻿using IRCEM.CiCd.SqlDeployer.Config;
using IRCEM.CiCd.SqlDeployer.Services.Config;

namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

sealed class HistoriqueForEnvAndDb
{
    public HistoriqueRepository Repository { get; private set; }

    public IDbSettings Db { get; private set; }

    public Environements Env { get; private set; }

    public HistoriqueForEnvAndDb(
        HistoriqueRepository Repository,
        IDbSettings db,
        Environements env)
    {
        this.Repository = Repository;
        Db = db;
        Env = env;
    }
}
