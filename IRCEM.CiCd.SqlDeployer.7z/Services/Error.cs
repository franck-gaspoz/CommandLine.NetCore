﻿using CommandLine.NetCore.Services.Text;

namespace IRCEM.CiCd.SqlDeployer.Services;

class Error
{
    readonly Texts _texts;

    public Error(Texts texts) => _texts = texts;

    public ArgumentException Argument(string textId, params object?[] parameters)
        => new(
            _texts._(textId, parameters));

    public ArgumentException Argument(string textId, string message, params object?[] parameters)
        => new(
            _texts._(textId, parameters)+message);
}
