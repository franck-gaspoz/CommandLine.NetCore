﻿using Config.Net;

using IRCEM.CiCd.SqlDeployer.Config;

namespace IRCEM.CiCd.SqlDeployer.Services.Config;

sealed class ConfigManager
{
    public ISettings Settings { get; private set; }

    IDeploiementSQLSettings _settings => Settings.DeploiementSQL;

    readonly Error _error;

    public ConfigManager(Error error)
        => (Settings, _error) =
            (new ConfigurationBuilder<ISettings>()
                .UseEnvironmentVariables()
                .UseJsonFile("Config/appSettings.json")
                .Build(),
             error);

    public IEnumerable<IDbSettings> GetDbSettings(Environements env)
    {
        var dbSettings = env switch
        {
            Environements.Default => _settings.Dbs.Default,
            Environements.Developement => _settings.Dbs.Developement,
            Environements.Recette => _settings.Dbs.Recette,
            Environements.Qualification => _settings.Dbs.Qualification,
            Environements.PreProduction => _settings.Dbs.PreProduction,
            Environements.Production => _settings.Dbs.Production,
            _ => _settings.Dbs.Developement
        };
        return !dbSettings.Any() ?
            throw _error.Argument("EnvironementDbsNonDefini", env)
            : dbSettings;
    }

    public IDbScriptsSettings GetDbScriptsSettings(TypesDbs typeDb)
    {
        var dbScriptsSettings = typeDb switch
        {
            TypesDbs.SqlServer => _settings.Scripts.SqlServer,
            TypesDbs.Postgresql => _settings.Scripts.Postgresql,
            _ => _settings.Scripts.Postgresql
        };
        return dbScriptsSettings is null ?
            throw _error.Argument("ScriptDbNonDefini", typeDb)
            : dbScriptsSettings;
    }
}