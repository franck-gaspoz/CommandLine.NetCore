﻿-- fabrique une database de test
drop database if exists idr_test_dbu;

CREATE DATABASE idr_test_dbu
    WITH 
    OWNER = idr_user
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.utf8'
    LC_CTYPE = 'en_US.utf8'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;
