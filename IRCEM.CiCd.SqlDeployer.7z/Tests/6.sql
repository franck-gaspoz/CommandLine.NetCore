﻿CREATE TABLE "TestUpdateSQL" (
  "Id" serial NOT NULL,
  PRIMARY KEY ("Id"),
  "Name" character varying NULL DEFAULT 'is null'
);
