﻿namespace IRCEM.CiCd.SqlDeployer.Config;

public interface IDbSettings
{
    string Id { get; }

    string Type { get; }

    string Connexion { get; }
}
