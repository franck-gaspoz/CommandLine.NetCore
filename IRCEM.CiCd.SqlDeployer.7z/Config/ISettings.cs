﻿namespace IRCEM.CiCd.SqlDeployer.Config;

public interface ISettings
{
    IDeploiementSQLSettings DeploiementSQL { get; }

    string TAG_VERSION { get; }

    string CurrentEnvironement { get; }

    bool ModeCICD { get; }
}
