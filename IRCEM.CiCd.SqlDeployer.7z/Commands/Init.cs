﻿using System;

using CommandLine.NetCore.Services.CmdLine.Arguments;
using CommandLine.NetCore.Services.CmdLine.Commands;

using IRCEM.CiCd.SqlDeployer.Services;
using IRCEM.CiCd.SqlDeployer.Services.Config;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

namespace IRCEM.CiCd.SqlDeployer.Commands;

sealed class Init : AbstractCommand
{
    List<Environements> _envs = new();
    string _build = string.Empty;
    bool _noHistorique;
    bool _noFetch;
    bool _noTag;
    bool _dropTable;
    bool _skipSQL;
    bool _simule;
    string? _dumpSql;
    readonly GitRepository _gitRepo;
    readonly Historiques _historiques = new();
    readonly HistoriqueForEnvAndDbBuilder _histoEnvDbBuilder;

    public Init(
        CommandServices services,
        GitRepository gitRepo,
        HistoriqueForEnvAndDbBuilder histoEnvDbBuilder) : base(services)
        => (_gitRepo, _histoEnvDbBuilder) = (gitRepo, histoEnvDbBuilder);

    protected override CommandResult Execute(ArgSet args) =>
        For(Opt<List<Environements>>("env"))
        .Do(() => InitializeHistoriqueSQL)
        .Options(
            Opt<string>("build"),
            Opt<int>("script"),
            Opt("no-historique"),
            Opt("no-fetch"),
            Opt("no-tag"),
            Opt("drop-table"),
            Opt("skip-sql"),
            Opt("simule"),
            Opt<string>("dump-sql"))
        .With(args);

    void InitializeHistoriqueSQL(
        Opt<List<Environements>> envOpt,
        Opt<string> buildOpt,
        Opt<int> scriptOpt, 
        Opt noHistoriqueOpt,
        Opt noFetchOpt,
        Opt noTagOpt,
        Opt dropTableOpt,
        Opt skipSQLOpt,
        Opt simuleOpt,
        Opt<string> dumpSqlOpt)
    {
        _simule = simuleOpt.IsSet;
        _dumpSql = dumpSqlOpt.IsSet ? dumpSqlOpt.GetValue() : null;
        _envs = envOpt.GetValue()!;
        _build = GetBuild(buildOpt);
        _dropTable = dropTableOpt.IsSet;
        _skipSQL = skipSQLOpt.IsSet;
        (_noHistorique, _noFetch, _noTag) =
            ToBool(noHistoriqueOpt, noFetchOpt, noTagOpt);
        var noScript = scriptOpt.IsSet ?
            scriptOpt.GetValue() : -1;

        if (DebugEnabled)
        {
            DumpVar("environements", string.Join(',', _envs));
            DumpVar("build", _build);
            DumpVar("noScript", noScript.ToString());
            DumpVar("noHistorique", _noHistorique + "");
            DumpVar("noFetch", _noFetch + "");
            DumpVar("noTag", _noTag + "");
            DumpVar("skipSQL", skipSQLOpt.IsSet + "");
            DumpVar("simule", _simule + "");
            DumpVar("dumpSql", _dumpSql + "" );
        }

        if (_dumpSql is not null)
        {
            var handle = File.OpenHandle(_dumpSql, FileMode.Create, FileAccess.ReadWrite, FileShare.ReadWrite);
            handle.Close();
        }

        InitEnvironements();
        _gitRepo.InitRepository(this, _noFetch);
        SaveUpdates(noScript);
        _gitRepo.Tag(this, _build, _noTag);
    }

    void SaveUpdates(int noScript)
    {
        foreach (var env in _envs)
        {
            OutputSection(T("InitialisationHistorique", env));

            foreach (var historique in _historiques.ByEnv[env])
            {
                RunTask(SaveUpdatesForEnvironement(
                    _build,
                    historique,
                    noScript));
            }
        }
    }

    async Task SaveUpdatesForEnvironement(
        string build,
        HistoriqueForEnvAndDb historique,
        int noScript)
    {
        OutputAction(T("MiseAJourHistorique"));

        var updates = await historique.Repository
            .GetUpdates(
                _gitRepo,
                historique.Db.Id,
                noScript);

        foreach (var scriptSQL in updates)
            OutputTrace(scriptSQL.ToString());

        try
        {
            if (!_noHistorique)
            {
                if (_simule)
                    OutputWarning(T("EtapeIgnoree"));

                await historique.Repository
                    .AddUpdates(
                        build, 
                        updates,
                        _simule,
                        _dumpSql);

                OutputActionHighlight(T("HistoriqueMisAJour"));
            }
            else
            {
                OutputWarning(T("EtapeIgnoree"));
            }
        }
        catch (Exception updateException)
        {
            if (updateException.InnerException is null)
                throw;
            throw updateException.InnerException;
        }
    }

    void InitEnvironements()
    {
        _historiques.Clear();
        foreach (var env in _envs)
        {
            OutputSection(T("InitialisationEnv", env));
            _histoEnvDbBuilder
                .AddHistoriqueRepositoryForEnvAndDb(env)
                .Build(_historiques);

            foreach (var historique in _historiques.ByEnv[env])
            {
                OutputAction(T("CnxDbEnCours"), historique.Db.Id);
                OutputTrace(historique.Db.Connexion);

                if (!_skipSQL)
                {
                    if (_dropTable)
                        DropTable(historique.Repository);
                    BuildTable(historique.Repository);
                    OutputActionHighlight(T("TableCreee"));
                }
                else
                    OutputWarning(T("EtapeIgnoree"));
            }
        }
    }

    void DropTable(HistoriqueRepository repo)
    {
        OutputAction(T("DropTable"));

        if (_simule)
            OutputWarning(T("EtapeIgnoree"));

        RunTaskWithSQLTrace(repo.DropTable(_simule,_dumpSql));
    }

    void BuildTable(HistoriqueRepository repo)
    {
        OutputAction(T("CreateTable"));

        if (_simule)
            OutputWarning(T("EtapeIgnoree"));

        RunTaskWithSQLTrace(repo.CreateTable(_simule, _dumpSql));
    }
}
