﻿using CommandLine.NetCore.Services.CmdLine.Arguments;
using CommandLine.NetCore.Services.CmdLine.Commands;

using IRCEM.CiCd.SqlDeployer.Services;
using IRCEM.CiCd.SqlDeployer.Services.Config;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git.Models;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

namespace IRCEM.CiCd.SqlDeployer.Commands;

sealed class Rollback : DeployCommand
{
    public Rollback(
        CommandServices services,
        GitRepository gitRepo,
        HistoriqueForEnvAndDbBuilder histoEnvDbBuilder) : base(
            services, gitRepo, histoEnvDbBuilder)
    { }

    protected override CommandResult Execute(ArgSet args) =>
        For(Opt<List<Environements>>("env"))
        .Do(() => RollbackSQL)
        .Options(
            Opt<string>("build"),
            Opt("no-fetch"),
            Opt("simule"),
            Opt<string>("dump-sql"))
        .With(args);

    void RollbackSQL(
        Opt<List<Environements>> envOpt,
        Opt<string> buildOpt,
        Opt noFetchOpt,
        Opt simuleOpt,
        Opt<string> dumpSqlOpt)
    {
        InitOpts(
            envOpt,
            buildOpt,
            noFetchOpt,
            simuleOpt,
            dumpSqlOpt);

        if (ConfigManager.Settings.CurrentEnvironement ==
            Environements.Production.ToString())
            throw Error.Argument("RollBackInterditEnProd");

        if (ConfigManager.Settings.ModeCICD)
            throw Error.Argument("RollbackInterditEnModeCICD");

        List<SQLScript> getUpdates(HistoriqueForEnvAndDb historique)
            => RunTask(
                historique.Repository
                    .GetRollbacks(
                        GitRepo,
                        historique.Db.Id,
                        Build))
                .OrderByDescending(x => x.Number)
                .ToList();

        GitRepo.InitRepository(this, NoFetch);
        InitEnvironementsAndRunScripts(getUpdates);
        SaveUpdates(getUpdates);
    }
}
