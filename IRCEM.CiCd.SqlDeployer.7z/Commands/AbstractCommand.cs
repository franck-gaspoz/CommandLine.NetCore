﻿using AnsiVtConsole.NetCore;

using CommandLine.NetCore.Services.CmdLine.Arguments;
using CommandLine.NetCore.Services.CmdLine.Commands;

using IRCEM.CiCd.SqlDeployer.Commands.GlobalOpts;
using IRCEM.CiCd.SqlDeployer.Config;
using IRCEM.CiCd.SqlDeployer.Services;
using IRCEM.CiCd.SqlDeployer.Services.Config;

namespace IRCEM.CiCd.SqlDeployer.Commands;

abstract class AbstractCommand : Command, IOutput
{
    protected Error Error { get; }

    protected ConfigManager ConfigManager { get; }

    protected AbstractCommand(CommandServices services)
        : base(services.Dependencies) =>
            (Error, ConfigManager) =
                (services.Error, services.ConfigManager);

    const string TraceColor = "(f=green)";
    const string ActionColor = "(f=white)";
    const string SymbolColor = "(f=gray)";
    const string NameColor = "(f=cyan)";
    const string ValueColor = "(f=green)";
    const string TitleColor = "(f=yellow)";
    const string ProcessColor = "(f=blue)";

    public IAnsiVtConsole GetConsole() => Console;

    public void DumpVar(string name, string value)
        => Console.Out.WriteLine(NameColor + name + SymbolColor + "=" + ValueColor + value);

    public void OutputSection(string text)
        => Console.Out.WriteLine("(br,uon)" + TitleColor + text + "(tdoff,br)");

    public void OutputAction(string text1, string text2)
        => Console.Out.WriteLine(ActionColor + text1 + SymbolColor + " : " + NameColor + text2);

    public void OutputTrace(string text)
        => Console.Out.WriteLine(TraceColor + text);

    public void OutputProcess(string text)
        => Console.Out.WriteLine(ProcessColor + text);

    public void OutputAction(string text)
        => Console.Out.WriteLine(ActionColor + text);

    public void OutputActionHighlight(string text)
        => Console.Out.WriteLine("(f=white,b=blue)--> " + ActionColor + text + "(tdoff)");

    public void OutputWarning(string text)
        => Console.Logger.LogWarning(text);

    public void OutputError(string text)
        => Console.Logger.LogError(text);

    protected static (bool, bool, bool) ToBool(Opt opt1, Opt opt2, Opt opt3)
        => (opt1.IsSet, opt2.IsSet, opt3.IsSet);

    protected List<Environements> GetEnv(Opt<List<Environements>> envOpt)
        => envOpt.IsSet || envOpt.GetValue() is not null ? envOpt.GetValue()!
            : new() { 
                ConfigManager
                    .Settings
                    .CurrentEnvironement
                    .ToEnvironement(Error) };

    protected string GetBuild(Opt<string> buildOpt)
    {
        var build = buildOpt.IsSet ? buildOpt.GetValue()!
            : ConfigManager.Settings.TAG_VERSION;
        if (string.IsNullOrWhiteSpace(build))
            throw Error.Argument("NoBuildVide");
        return build;
    }

    public string T(string textId, params object?[] parameters)
        => new(
            Texts._(textId, parameters));

    protected static ReturnType RunTask<ReturnType>(Task<ReturnType> task)
    {
        task.Wait();
        return task.Result;
    }

    protected void RunTaskWithSQLTrace(Task<int> task)
    {
        task.Wait();
        var nb = task.Result;
        OutputTrace(T(
            nb > 1 ? "LigneAffectee" : "LignesAffectees",
            nb));
    }

    protected bool DebugEnabled
        => GlobalSettings.SettedGlobalOptsSet.Contains<Debug>();

    protected static void RunTask(Task task) => task.Wait();
}
