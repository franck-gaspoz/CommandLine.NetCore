﻿using AnsiVtConsole.NetCore;

namespace IRCEM.CiCd.SqlDeployer.Commands;

interface IOutput
{
    IAnsiVtConsole GetConsole();
    void DumpVar(string name, string value);
    void OutputAction(string text);
    void OutputAction(string text1, string text2);
    void OutputSection(string text);
    void OutputTrace(string text);
    void OutputActionHighlight(string text);
    void OutputWarning(string text);
    void OutputError(string text);
    void OutputProcess(string text);
    string T(string textId, params object?[] parameters);
}