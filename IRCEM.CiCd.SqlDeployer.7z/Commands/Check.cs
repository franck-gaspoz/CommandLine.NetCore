﻿using CommandLine.NetCore.Services.CmdLine.Arguments;
using CommandLine.NetCore.Services.CmdLine.Commands;

using IRCEM.CiCd.SqlDeployer.Services;
using IRCEM.CiCd.SqlDeployer.Services.Config;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

namespace IRCEM.CiCd.SqlDeployer.Commands;

sealed class Check : AbstractCommand
{
    List<Environements> _envs = new();
    bool _noFetch;
    readonly GitRepository _gitRepo;
    readonly Historiques _historiques = new();
    readonly HistoriqueForEnvAndDbBuilder _histoEnvDbBuilder;
    bool _historique;

    public Check(
        CommandServices services,
        GitRepository gitRepo,
        HistoriqueForEnvAndDbBuilder histoEnvDbBuilder) : base(services)
        => (_gitRepo, _histoEnvDbBuilder) = (gitRepo, histoEnvDbBuilder);

    protected override CommandResult Execute(ArgSet args) =>
        For(Opt<List<Environements>>("env"))
        .Do(() => CheckHistoriqueSQL)
        .Options(Opt("no-fetch"),Opt("historique"))
        .With(args);

    void CheckHistoriqueSQL(
        Opt<List<Environements>> envOpt,
        Opt noFetchOpt,
        Opt historiqueOpt
        )
    {
        _envs = envOpt.GetValue()!;
        _noFetch = noFetchOpt.IsSet;
        _historique = historiqueOpt.IsSet;

        if (DebugEnabled)
        {
            DumpVar("environements", string.Join(',', _envs));
            DumpVar("noFetch", _noFetch + "");
        }

        _gitRepo.InitRepository(this, _noFetch);
        InitAndDumpEnvironements();
    }

    void InitAndDumpEnvironements()
    {
        _historiques.Clear();
        foreach (var env in _envs)
        {
            OutputSection(T("LectureEnv", env));
            _ = _histoEnvDbBuilder
                .AddHistoriqueRepositoryForEnvAndDb(env)
                .Build(_historiques);

            foreach (var historique in _historiques.ByEnv[env])
            {
                OutputAction(T("CnxDbEnCours"), historique.Db.Id);
                OutputTrace(historique.Db.Connexion);

                var (exists, error) = RunTask<(bool, string?)>(historique.Repository.CheckExists());

                if (!exists)
                {
                    OutputError(T("PasDHistoriquePourLEnv", env));
                    OutputError("--> "+error!);
                }
                else
                {
                    OutputAction(T("LectureHistorique", env));

                    var list = RunTask(historique.Repository
                        .GetList());

                    var flatList = RunTask(historique.Repository
                        .GetDelivered());

                    static string FormatText(string script,string build,string date,string rollBack,string description )
                        => string.Format("{0,12} │ {1,10} │ {2,19} │ {3,10} | {4}",
                                script,
                                build,
                                date,
                                rollBack,
                                description);

                    static string ToText(HistoriqueSQL h) =>
                        FormatText(
                                h.Script.ToString(),
                                h.Build,
                                h.Date.ToString(),
                                h.IsRollback ? "rollback" : "",
                                h.Description);

                    var n = 12 + 10 + 19 + (3 * 3) + 8 + 6 + 60;
                    void Header() =>
                            OutputTrace("(uon)" + FormatText(
                                T("NoScript"),
                                T("Build"),
                                T("Date"),
                                T("RollBack"),
                                T("Description")).PadRight(n)
                                + "(tdoff)");

                    if (_historique)
                    {
                        Console.Out.WriteLine();
                        OutputTrace(T("ContenuHistorique"));

                        Console.Out.WriteLine();

                        Header();

                        foreach (var h in list)
                            OutputTrace(ToText(h));
                    }

                    Console.Out.WriteLine();
                    OutputTrace(T("ScriptsDeployes", flatList.Count));

                    Console.Out.WriteLine();

                    Header();

                    foreach (var h in flatList)
                        OutputTrace(ToText(h));

                    Console.Out.WriteLine();
                    var buildCourant = RunTask(historique.Repository.GetCurrentBuild());
                    OutputAction(T("BuildCourant"), buildCourant ?? string.Empty);
                    Console.Out.WriteLine();

                    var updates = RunTask(historique.Repository
                        .GetUpdates(
                            _gitRepo,
                            historique.Db.Id));

                    if (!updates.Any())
                    {
                        OutputActionHighlight(T("DbAJour"));
                    }
                    else
                    {
                        OutputActionHighlight(T("ScriptsAJouer"));
                        Console.Out.WriteLine();
                        foreach (var scriptSQL in updates)
                            OutputTrace(scriptSQL.ToString());
                    }
                }
            }
        }
    }
}

